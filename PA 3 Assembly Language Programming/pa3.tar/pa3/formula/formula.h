#ifndef formula_h
#define formula_h

int main(int argc, const char * argv[]);

#endif
