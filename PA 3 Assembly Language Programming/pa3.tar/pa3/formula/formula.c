#include <stdio.h>
#include <stdlib.h>
#include "nCr.h"
#include <time.h>
#include <sys/time.h>

int main(int argc, const char * argv[])
{
	int q = 0;
	int p;
	int c;

	struct timeval start, end;

	if (argv[1][0] == '-' && argv[1][1] == 'h') {
		printf("Usage: formula <positive integer>");
	} else {
		p = atoi(argv[1]);
		
		gettimeofday(&start, NULL);

		printf("(1 + x)^%i = ", p);

		if (p == 0){
			printf("0");
		}
		printf ("1 +");
		for (; q <= p; q++) {

			c = nCr(p, q);

			if (c == -1) {
				printf("Multiplication overflow. \n");
				return 1;
			} else {
				if (q != 0){
					printf("%i x^%i ",c , q);				
				}
				if (q != p && q != 0){
					printf("+ ");
				}
			}
		}

		gettimeofday(&end, NULL);

	}

	printf("\n%ld microseconds\n", ((end.tv_sec * 1000000 + end.tv_usec)
		  - (start.tv_sec * 1000000 + start.tv_usec)));

	return 0;
}
